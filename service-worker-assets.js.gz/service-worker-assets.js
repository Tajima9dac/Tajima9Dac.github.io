self.assetsManifest = {
  "version": "bkZe7Htw",
  "assets": [
    {
      "hash": "sha256-4+9kYvavBmJ6tPlTT6963GuEntTs+Ok2rFua9arR8BM=",
      "url": "WasmTest02.styles.css"
    },
    {
      "hash": "sha256-AphMIB3qLsMhekY4v9fGwVJ6RALzwuZEcZcWAlxMjgQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.ykp6py1h0n.wasm"
    },
    {
      "hash": "sha256-061CU+7WhtXhoGJ2/w2Wg+CI/WqRrUcLV2ecAmFad9E=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.d8oq5gblzr.wasm"
    },
    {
      "hash": "sha256-4/y5/QPYXqe/JifaGGThUoFSPc3JJCwhkA2O3dAtssY=",
      "url": "_framework/Microsoft.AspNetCore.Components.lel7vvw96p.wasm"
    },
    {
      "hash": "sha256-wcu3iuPJejmA0aeV8AmhINoqWC8pF5jORsMjats4JrA=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.jftl4iube1.wasm"
    },
    {
      "hash": "sha256-73fjp6QTz13qqhp5ePm9w7uF/0igOJntFdJ9ySeA+4c=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.5r4cx1o4hq.wasm"
    },
    {
      "hash": "sha256-YCtjvABwm5fkaWf4+QYQxWMKG6cvTym5Djrj72DM068=",
      "url": "_framework/Microsoft.Extensions.Configuration.oedzypg1by.wasm"
    },
    {
      "hash": "sha256-0WRkrf/d8sNluVTKWc1FojtSGktqCxQeuqv5+rKajlo=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.9ik87pek18.wasm"
    },
    {
      "hash": "sha256-sa4XiUO87AlejrceqNQWBhT/i24xtKQ6KuNtdDrPNQE=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.d9m8gf6id8.wasm"
    },
    {
      "hash": "sha256-f4/VD7c7KmKYYZggBefEqty793ENhSJ4jcaKRwFhi7E=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.d1l0uyua5u.wasm"
    },
    {
      "hash": "sha256-qsSxaXDaD3XGAJsq5/wE5cZZhU+/0BFEPEomwVOCNrQ=",
      "url": "_framework/Microsoft.Extensions.Logging.yhdsguskah.wasm"
    },
    {
      "hash": "sha256-R56xoItP6kJstVF0XjcNJ0sj5QEbvyDndLL1QTEKDlA=",
      "url": "_framework/Microsoft.Extensions.Options.jtaew4890w.wasm"
    },
    {
      "hash": "sha256-G4XgdWPq9VnreFRqc5E+wD9aaWyvMafv1IlgAEROBW4=",
      "url": "_framework/Microsoft.Extensions.Primitives.t6jnev14u6.wasm"
    },
    {
      "hash": "sha256-vZx0UUYZqc8Y3b9RcYhRAtkkSzza7gbshLcdNh8z/Vk=",
      "url": "_framework/Microsoft.JSInterop.5qhwjaaih1.wasm"
    },
    {
      "hash": "sha256-FTVJx7gilBV/VWu+ibz7K8ueo7JUXPGj94aH0rf2FXQ=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.58jjh3bwur.wasm"
    },
    {
      "hash": "sha256-AwUYelxuSagTYPE1EeFkitXA8rN3EmG8ha/c/TurPy0=",
      "url": "_framework/System.Collections.7n0760g1e3.wasm"
    },
    {
      "hash": "sha256-X4rZsZ+cVbi0x4D+wrh6WVfkmFVtK8+ijQNcxf29KU4=",
      "url": "_framework/System.Collections.Concurrent.5vw97c9vfn.wasm"
    },
    {
      "hash": "sha256-6zvpQjwjz61m+XhYfBTdGhAGG2Yh5fAehFAA9rV7ov8=",
      "url": "_framework/System.Collections.Immutable.rsqpcr5fv9.wasm"
    },
    {
      "hash": "sha256-JKTTvsOJYGxxPrp0Bfo016Od0pGkQ4K42ix8qFy8X/k=",
      "url": "_framework/System.ComponentModel.87e9suq6nz.wasm"
    },
    {
      "hash": "sha256-tRWgunL+/s3G0kE/wC/bYybHULwuA44ahJI0lbQYeTA=",
      "url": "_framework/System.Console.rcgahykbtp.wasm"
    },
    {
      "hash": "sha256-xUqcqszEKrklKFw0g/x36uK7V6/LYTgbO2+R7VnuZKA=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.pr2v7hi3ks.wasm"
    },
    {
      "hash": "sha256-ybH+sm0M8AtVcGVSt7C5l6WYbkAVqPv9y8rjm7FFjH8=",
      "url": "_framework/System.IO.Pipelines.pw7nunldbe.wasm"
    },
    {
      "hash": "sha256-QHTl2JcMxNszMjshqemnQD47dZ7h+XNICdlgaPoJgeM=",
      "url": "_framework/System.Linq.0gk7103p15.wasm"
    },
    {
      "hash": "sha256-IbKlP/1xEalAAq8J9ZrdSG191VdgtR+jznDCA2yua40=",
      "url": "_framework/System.Memory.tdvls1uo01.wasm"
    },
    {
      "hash": "sha256-D7tzXpXqOtV8dxrDMcBdCUxLf/ssg+AAVLmyBq8S23M=",
      "url": "_framework/System.Net.Http.Json.vsoqrclr0s.wasm"
    },
    {
      "hash": "sha256-GX8+l+sozz6lFW4rvUcOJgANQm9VmQ5Fv7onWjxCL+c=",
      "url": "_framework/System.Net.Http.viozimnpyk.wasm"
    },
    {
      "hash": "sha256-vXxgDY1qlA3+/6lhtxS+M5g6+rQigj62PcBcKqkf+X4=",
      "url": "_framework/System.Net.Primitives.rqs3v0t645.wasm"
    },
    {
      "hash": "sha256-P03rmby7O8rABsFtwhwQYwknSknZEOKk4C0Je+4gT+M=",
      "url": "_framework/System.Private.CoreLib.d15ppd4eo7.wasm"
    },
    {
      "hash": "sha256-FeC4mPLht19eJlKwafzlndJRdPVR3Dj6xOF/kVB0Iic=",
      "url": "_framework/System.Private.Uri.1xn42n9ok3.wasm"
    },
    {
      "hash": "sha256-616dBlKoT89bsUznAsXjFyNyckmQiNK3pleiln/B2Uc=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.3e76cmtii9.wasm"
    },
    {
      "hash": "sha256-8bdG6k1X3nNcD3a4uzBNVvf4H9gdHGrL4/+qR8lbWNk=",
      "url": "_framework/System.Runtime.pq73yjqh9g.wasm"
    },
    {
      "hash": "sha256-F8O3F97uHL3zQT4RNsDUTfe+z6kUG3ZbkFOc/la8Udg=",
      "url": "_framework/System.Security.Cryptography.1ez7qpjo6x.wasm"
    },
    {
      "hash": "sha256-aoioLxa+mJwpJAMPFZGtGJnIB0fN0GZc65VziqPDT6M=",
      "url": "_framework/System.Text.Encodings.Web.ye9nlxyiq9.wasm"
    },
    {
      "hash": "sha256-AaGJ8yHyrdHvrNHkZNZS6p1vMKrK834HS9hZc5do4A4=",
      "url": "_framework/System.Text.Json.rtxfy5fi85.wasm"
    },
    {
      "hash": "sha256-2BPZD6KhtCiJUhd9Fw+aUU4FkTW2E+sntvTvQ9eWM5Q=",
      "url": "_framework/System.Text.RegularExpressions.os6zj3gog4.wasm"
    },
    {
      "hash": "sha256-UilmgL5binDhlyjcletQ27/HhYf6yVzeF37UYLq0f7Q=",
      "url": "_framework/WasmTest02.qt49qrfbj2.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.66stpp682q.js"
    },
    {
      "hash": "sha256-+M+hqxF1YK0OlVjdR+qrfExPaFE669SD/EqIDSrelu4=",
      "url": "_framework/dotnet.gqwxopxqlg.js"
    },
    {
      "hash": "sha256-h8fZQUGTTd/Yau5WAQj7UIe9MoBxvM33iqrWD7Te5Jc=",
      "url": "_framework/dotnet.native.p80pfb3jvl.js"
    },
    {
      "hash": "sha256-Ty/uwxUSS/pHTl/PMsXvZb0c+u+U+em+d+WvFZiM1G4=",
      "url": "_framework/dotnet.native.v85v3crj2l.wasm"
    },
    {
      "hash": "sha256-cajUr4vA/MpLPWj3omULUOwEQw3i8CE2n8AmDheqWBM=",
      "url": "_framework/dotnet.runtime.peu2mfb29t.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-yRJ49z3y3rHi/X6jpbhaZS6+RJBCP3/2qRNriPwlJ3c=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-QRwjV2J4fH07sCpxFSbc3LdBMCtGYO4XzIhdOPGx33Y=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-vah01EMcWQlicMiReBzsKZq6KVhrH5KhfBvFHXMmJHc=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-j7BE8ZvhVs+WNUqLCDYmRFFPe013x3dT4EOJxrpmAgA=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-FWwliMEEKnZsDWMbH9TIHtZgZDUphC3spqKMY6dcfS4=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-Xc4waOrvLBSRSWjuPygeYwa59NqUD7Tr1WZIsyrS+gE=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-B6SuNEqQ5z+z+5CZ2JhX5wh98S4t1/+M/5hbZnY/9ws=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-QNDym3ewWGLNtvtz8sG+gkaw7iqt04f9ZED8rdnGp9k=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-GOikriQsuT54msA/Uv515pkYQ9vOFrzPJ0uFaNbDlgQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-X7PPG66yKuppXQ6NXU1Iv19HQNzcsQ41CRKiHp7dRpY=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-kfiGxJtY0AbxQvBoNsl+bC3+gXgGsj4BFqoC4VvKx6U=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-JinLFiCZrlBCiYAmIyNpeOn9b5sWcOjMNfoL0Jjl3+s=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-enKgCMkYmCpfEcmg6Annbmc40VZ/A6aYYSQjZfVn2cU=",
      "url": "sample-data/weather.json"
    },
    {
      "hash": "sha256-xpiBU5JaivHsXBFC8UthPjsqS4burkZdfW/lSWOiRK8=",
      "url": "web.config"
    }
  ]
};
